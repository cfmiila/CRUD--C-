using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Diosmio.Models;

namespace Diosmio.Repository
{
    public interface IVeiculoRepository
    {
        public VeiculoModel Adicionar(VeiculoModel veiculo);
        public bool Deletar(int id);
        public VeiculoModel Editar(VeiculoModel veiculo);
        public VeiculoModel ListarId(int id);
        public List<VeiculoModel> ListarVeiculos();
        
    }
}