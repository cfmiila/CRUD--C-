 using System;
 using System.Collections.Generic;
 using System.Linq;
 using System.Threading.Tasks;
 using Microsoft.AspNetCore.Mvc;
 using Diosmio.Data;
 using Diosmio.Models;

 namespace Diosmio.Repository
 {
     public class VeiculoRepository : IVeiculoRepository
     {
         private readonly LocadoraContext _locadoraContext;
         public VeiculoRepository(LocadoraContext locadoraContext){
             _locadoraContext = locadoraContext;
         }
         public VeiculoModel Adicionar(VeiculoModel veiculo)
         {
            
             _locadoraContext.SaveChanges();
             return veiculo;
         }

         public bool Deletar(int id)
         {
             VeiculoModel veiculoDB = ListarId(id);
             if(veiculoDB == null) throw new Exception("Houve um erro ao deletar o Veiculo!");
             _locadoraContext.Veiculos.Remove(veiculoDB);
             _locadoraContext.SaveChanges();
             return true;
         }

         public VeiculoModel Editar(VeiculoModel veiculo)
         {
          //O id aqui estava em minusculo e você tinha colocado em models ela como maisculo ID ao inves de Id
             VeiculoModel veiculoDB = ListarId(veiculo.ID);
             if(veiculoDB == null) throw new Exception("Houve um Erro na atualização do Veiculo!");
             veiculoDB.Modelo = veiculo.Modelo;
             veiculoDB.Estado = veiculo.Estado;
             veiculoDB.Preco = veiculo.Preco;

             _locadoraContext.Veiculos.Update(veiculoDB);
            _locadoraContext.SaveChanges();
             return veiculoDB;
         }

         public VeiculoModel ListarId(int id)
         {
          //O id aqui estava em minusculo e você tinha colocado em models ela como maisculo ID ao inves de Id
             return _locadoraContext.Veiculos.FirstOrDefault(x => x.ID == id);
         }

         public List<VeiculoModel> ListarVeiculos(){
             return _locadoraContext.Veiculos.ToList();
         }


     }
 }
    // criado um arquivo como interface ao inves de classe, IVeiculoRepository
    // public interface IVeiculosRepository
    // {
       //  void Adicionar(VeiculoModel veiculo);
       //  void Editar(VeiculoModel veiculo);
       //  VeiculoModel ListarId(int id);
       //  string? ListarVeiculos();
    // }
 //}