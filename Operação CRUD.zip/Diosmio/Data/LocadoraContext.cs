using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Diosmio.Models;
using Microsoft.EntityFrameworkCore;

namespace Diosmio.Data
{
    public class LocadoraContext : DbContext
    {
        public LocadoraContext(DbContextOptions<LocadoraContext> options) : base(options){}
        public DbSet<VeiculoModel> Veiculos { get; set; }
    }
}