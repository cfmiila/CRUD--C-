using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Diosmio.Models
{
    public class VeiculoModel
    {
        public int ID { get; set; }
        public required string Modelo{ get; set; }
        public float Preco { get; set; }
        public required string Estado { get; set; }
    }
}